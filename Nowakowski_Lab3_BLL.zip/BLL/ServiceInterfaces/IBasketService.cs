﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    public interface IBasketService
    {
        void InsertProduct( BasketPositionRequestDTO product);
        void ChangeProductCount(int productId,int count);
        void DeleteProduct(int productId);
        void GenerateOrder(BasketPositionResponseDTO basket);
        void Payment(decimal amount, int userId);
    }
}
