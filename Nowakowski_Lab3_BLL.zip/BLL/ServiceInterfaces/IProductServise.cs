﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    public enum SelectSort
    {
        Name,
        Price,
        NameGroup,
        NameDes,
        PriceDes,
        NameGroupDes

    };

    public interface IProductServise
    {
        IEnumerable<ProductResponseDTO> GetProducts(SelectSort selectSort,string filtrName="", string filtrNameGroup="", int filtrIdGroup=-1, bool returnDisable=false);
        void AddNewPorduct(ProductRequestDTO product);
        void DeleteProduct(int productId);
        void DisableProduct(int productId);
        void ActiveProduct(int productId);



    }
}
