﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels
{
    public class OrderPositionResponseDTO
    {
        public int Amount { get; init; }
        public decimal Price { get; init; }
        public int? OrderId { get; init; }
        public List<BasketPosition> Items { get; init; } = new List<BasketPositionResponseDTO>();
    }
}
