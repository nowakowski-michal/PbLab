﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ProductGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //relacja do samego siebie
        public int? ParentId { get; set; }
        [ForeignKey(nameof(ParentId))]
        public ProductGroup? Parent { get; set; }
        public List<ProductGroup> ProductGroups { get; set; }
        //relacja z product wiele produktów w jednej grupie
        public List<Product> Products { get; set; }
    }
}
