﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Product
    {
        public int Id { get; set; }
        public double Price { get; set; }
        public string Image { get; set; }
        public bool IsActive { get; set; }
        public string Name { get; set; }
        // relacja z ProductGroup 1 id grupy
        
        public int? GroupId { get; set; }
        [ForeignKey(nameof(GroupId))]
        public ProductGroup? ProductGroup { get; set; }
        //relacja z basket position wiele koszykow 
        public List<BasketPosition>? BasketPositions { get; set; }


    }
}
