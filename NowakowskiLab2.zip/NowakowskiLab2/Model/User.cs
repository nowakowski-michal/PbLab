﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public enum Type { Admin, Causal }
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public  Type TypeUser { get; set; }
        public bool IsActive { get; set; }
        public int? GroupId { get; set; }
        [ForeignKey(nameof(GroupId))]
        public UserGroup? UserGroup { get; set; }
        //do relacji order user order 1-w
        public List<Order>? Orders { get; set; }
        public List<BasketPosition>? BasketPositions { get; set; }



    }
}
