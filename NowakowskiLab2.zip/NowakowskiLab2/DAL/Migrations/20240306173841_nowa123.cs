﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class nowa123 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "BasketPositions",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_BasketPositions_UserId",
                table: "BasketPositions",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_BasketPositions_Users_UserId",
                table: "BasketPositions",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BasketPositions_Users_UserId",
                table: "BasketPositions");

            migrationBuilder.DropIndex(
                name: "IX_BasketPositions_UserId",
                table: "BasketPositions");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "BasketPositions");
        }
    }
}
