﻿using Microsoft.EntityFrameworkCore;
using Model;
using System.Reflection.Metadata;

namespace DAL
{
    public class WebshopContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductGroup> ProductGroups { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<BasketPosition> BasketPositions { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderPosition> OrderPositions { get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder
      optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MnLab2;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .Entity<UserGroup>()
                .HasMany(e => e.Users)
                .WithOne(e => e.UserGroup)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<ProductGroup>()
                .HasMany(e => e.Products)
                .WithOne(e => e.ProductGroup)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<ProductGroup>()
                .HasOne(e => e.Parent)
                .WithMany(e => e.ProductGroups)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<OrderPosition>()
                .HasOne(e => e.Order)
                .WithMany(e => e.OrderPositions)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<BasketPosition>()
                .HasOne(e => e.Product)
                .WithMany(e => e.BasketPositions)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<BasketPosition>()
                .HasOne(e => e.User)
                .WithMany(e => e.BasketPositions)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder
                .Entity<Order>()
                .HasMany(e => e.OrderPositions)
                .WithOne(e => e.Order)
                .OnDelete(DeleteBehavior.ClientSetNull);

        }
    }
}