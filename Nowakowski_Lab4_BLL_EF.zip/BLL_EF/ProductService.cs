﻿using Azure;
using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Microsoft.EntityFrameworkCore;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_EF
{
    public class ProductService : IProductServise
    {
        private readonly WebshopContext db;

        public void AddNewPorduct(ProductRequestDTO product)
        {
            Product insertProduct = new Product
            {
                Price = product.Price,
                Image = product.Image,
                IsActive = product.IsActive,
                Name = product.Name,
                GroupId = product.GroupId
            };
            if (insertProduct.Price > 0)
            {
                db.Products.Add(insertProduct);
            }
        }

        public void DeleteProduct(int productId)
        {
            Product product = db.Products.Find(productId);
            if (product.BasketPositions == null)
            {
                db.Products.Remove(product);
            }
        }

        public void DisableProduct(int productId)
        {

            Product product = db.Products.Find(productId);
            if (product.BasketPositions == null)
            {
                product.IsActive = false;
                db.Entry(product).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            }

        }
        public void ActiveProduct(int productId)
        {
            Product product = db.Products.Find(productId);
            product.IsActive = true;
            db.Entry(product).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        }
        public IEnumerable<ProductResponseDTO> GetProducts(SelectSort selectSort, string filtrName = "", string filtrNameGroup = "", int filtrIdGroup = -1, bool returnDisable = false)
        {
            List<Product> products = new List<Product>();
            List<ProductResponseDTO> productsResponseDTO = new List<ProductResponseDTO>();
            products = db.Products.Include(x=>x.ProductGroup).ThenInclude(x=>x.Parent).ToList();

            foreach (Product product in products)
            {
                string groupName = " ";
                if (product.ProductGroup.Name != null)
                {

                    if (product.ProductGroup.Parent == null)
                    {
                        groupName = product.ProductGroup.Name;
                    }
                    else if (product.ProductGroup.Parent != null)
                    {
                        groupName = product.ProductGroup.Name;
                        foreach (var name in product.ProductGroup.Parent.Name)
                        {
                            groupName += "/" + product.ProductGroup.Parent.Name;
                        }
                        
                        
                    }
                }
                else
                {
                    groupName = " ";
                }

                ProductResponseDTO response = new ProductResponseDTO
                {
                    Id = product.Id,
                    Name = product.Name,
                    Price = product.Price,
                    NameGroup = groupName
                    
                };

                if (filtrIdGroup >= 0 && product.IsActive)
                {
                    if (response.Id == filtrIdGroup && !returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }
                else if (filtrName != "" && product.IsActive)
                {
                    if(response.Name == filtrName && !returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }
                else if(filtrNameGroup!= "" && product.IsActive)
                {
                    if(response.NameGroup == filtrNameGroup && !returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }
                else if (filtrIdGroup >= 0 && !product.IsActive)
                {
                    if (response.Id == filtrIdGroup && returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }
                else if (filtrName != "" && !product.IsActive)
                {
                    if (response.Name == filtrName && returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }
                else if (filtrNameGroup != "" && !product.IsActive)
                {
                    if (response.NameGroup == filtrNameGroup && returnDisable)
                    {
                        productsResponseDTO.Add(response);
                    }
                }


            }
            if (selectSort == SelectSort.Name)
            {
                return productsResponseDTO.OrderBy(x => x.Name);
            }
            else if(selectSort == SelectSort.NameDes) 
            {
                return productsResponseDTO.OrderByDescending(x => x.Name);
            }
            else if( selectSort == SelectSort.NameGroup) 
            {
                return productsResponseDTO.OrderBy(x => x.NameGroup);
            }
            else if (selectSort == SelectSort.NameGroupDes)
            {
                return productsResponseDTO.OrderByDescending(x => x.NameGroup);
            }
            else if (selectSort == SelectSort.Price)
            {
                return productsResponseDTO.OrderBy(x => x.NameGroup);
            }
            else
            {
                return productsResponseDTO.OrderByDescending(x => x.NameGroup);
            }





        }
    }
}
