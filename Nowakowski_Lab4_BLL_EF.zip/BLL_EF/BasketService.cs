﻿using BLL.DTOModels;
using BLL.ServiceInterfaces;
using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_EF
{
    public class BasketService : IBasketService
    {
        private readonly WebshopContext db;
        public void InsertProduct(BasketPositionRequestDTO product)
        {

            Product newProduct = db.Products.Find(product.ProductId);
            if (newProduct.IsActive)
            {
                BasketPosition basket = db.BasketPositions.Find(product.ProductId);
                basket.Product = newProduct;
                db.Entry(basket).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            }

        }
        public void ChangeProductCount(int productId, int count)
        {
            if (count > 0)
            {
                BasketPosition basket = db.BasketPositions.Find(productId);
                basket.Amount = count;
                db.Entry(basket).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            }
        }
            

        public void DeleteProduct(int productId)
        {
            BasketPosition basket = db.BasketPositions.Find(productId);
            basket.Product = null;
            db.Entry(basket).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

        }

        public void GenerateOrder(BasketPositionResponseDTO basket)
        {
            List<BasketPosition> basketPositions = db.Users.Find(basket.UserId).BasketPositions;

            OrderPosition orderPosition = new OrderPosition();
            orderPosition.Product.BasketPositions = basketPositions;
            Order order = new Order();
            order.OrderPositions.Add(orderPosition);
            order.User = db.Users.Find(basket.UserId);
            order.Date = DateTime.Now;

            db.Orders.Add(order);
        }

        public void Payment(decimal amount, int userId)
        {
            Order order = db.Orders.Where(x=>x.UserId==userId).First();
            if(amount == order.OrderPositions.Sum(x => x.Price))
            {
                order.IsPaid = true;
            }
        }
    }
}
